using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heap
{
    public class Heap<K, D> where K : IComparable<K>
    {
        private class Node : IHeapifyable<K, D>
        {
            public D Data { get; set; }
            public K Key { get; set; }
            public int Position { get; set; }

            public Node(K key, D value, int position)
            {
                Data = value;
                Key = key;
                Position = position;
            }

            public override string ToString()
            {
                return "(" + Key.ToString() + "," + Data.ToString() + "," + Position + ")";
            }
        }

        public int Count { get; private set; }
        private List<Node> data = new List<Node>();
        private IComparer<K> comparer;

        public Heap(IComparer<K> comparer)
        {
            this.comparer = comparer;
            if (this.comparer == null) this.comparer = Comparer<K>.Default;
            data.Add(new Node(default(K), default(D), 0));
        }

        public IHeapifyable<K, D> Min()
        {
            if (Count == 0) throw new InvalidOperationException("The heap is empty.");
            return data[1];
        }

        public IHeapifyable<K, D> Insert(K key, D value)
        {
            Count++;
            Node node = new Node(key, value, Count);
            data.Add(node);
            UpHeap(Count);
            return node;
        }

        private void UpHeap(int start)
        {
            int position = start;
            while (position != 1)
            {
                if (comparer.Compare(data[position].Key, data[position / 2].Key) < 0) Swap(position, position / 2);
                position = position / 2;
            }
        }

        private void Swap(int from, int to)
        {
            Node temp = data[from];
            data[from] = data[to];
            data[to] = temp;
            data[to].Position = to;
            data[from].Position = from;
        }

        public void Clear()
        {
            for (int i = 0; i <= Count; i++) data[i].Position = -1;
            data.Clear();
            data.Add(new Node(default(K), default(D), 0));
            Count = 0;
        }

        public override string ToString()
        {
            if (Count == 0) return "[]";
            StringBuilder s = new StringBuilder();
            s.Append("[");
            for (int i = 0; i < Count; i++)
            {
                s.Append(data[i + 1]);
                if (i + 1 < Count) s.Append(",");
            }
            s.Append("]");
            return s.ToString();
        }

        public IHeapifyable<K, D> Delete()
        {
            if (Count == 0) throw new InvalidOperationException("The heap is empty.");

            Node result = data[1];
            data[1] = data[Count];
            data[1].Position = 1;
            data.RemoveAt(Count);
            Count--;

            if (Count > 1) DownHeap(1);

            return result;
        }

        private void DownHeap(int start)
        {
            int position = start;
            while (position <= Count / 2)
            {
                int smallest = position;
                int left = 2 * position;
                int right = 2 * position + 1;

                if (left <= Count && comparer.Compare(data[left].Key, data[smallest].Key) < 0)
                    smallest = left;
                if (right <= Count && comparer.Compare(data[right].Key, data[smallest].Key) < 0)
                    smallest = right;

                if (smallest == position) break;

                Swap(position, smallest);
                position = smallest;
            }
        }

        public IHeapifyable<K, D>[] BuildHeap(K[] keys, D[] data)
        {
            if (Count != 0) throw new InvalidOperationException("The heap is not empty.");
            if (keys == null || data == null || keys.Length != data.Length)
                throw new ArgumentException("Invalid input arrays.");

            IHeapifyable<K, D>[] result = new IHeapifyable<K, D>[keys.Length];
            Count = keys.Length;

            for (int i = 0; i < keys.Length; i++)
            {
                Node node = new Node(keys[i], data[i], i + 1);
                this.data.Add(node);
                result[i] = node;
            }

            for (int i = Count / 2; i >= 1; i--)
                DownHeap(i);

            return result;
        }

        public void DecreaseKey(IHeapifyable<K, D> element, K new_key)
        {
            Node node = element as Node;
            if (node == null || node.Position < 1 || node.Position > Count || data[node.Position] != node)
                throw new InvalidOperationException("Invalid element.");

            if (comparer.Compare(new_key, node.Key) > 0)
                throw new ArgumentException("New key is larger than current key.");

            node.Key = new_key;
            UpHeap(node.Position);
        }
    }
}