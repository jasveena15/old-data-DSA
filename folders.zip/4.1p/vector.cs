using System;
using System.Collections.Generic;
using System.Text;
// using Vector;

namespace Vector
{
    public class Vector<T> where T : IComparable<T>
    {
        // This constant determines the default number of elements in a newly created vector.
        // It is also used to extended the capacity of the existing vector
        private const int DEFAULT_CAPACITY = 10;

        // This array represents the internal data structure wrapped by the vector class.
        // In fact, all the elements are to be stored in this private  array. 
        // You will just write extra functionality (methods) to make the work with the array more convenient for the user.
        private T[] data;

        // This property represents the number of elements in the vector
        public int Count { get; private set; } = 0;

        // This property represents the maximum number of elements (capacity) in the vector
        public int Capacity
        {
            get { return data.Length; }
        }

        // This is an overloaded constructor
        public Vector(int capacity)
        {
            data = new T[capacity];
        }

        // This is the implementation of the default constructor
        public Vector() : this(DEFAULT_CAPACITY) { }

        // An Indexer is a special type of property that allows a class or structure to be accessed the same way as array for its internal collection. 
        // For example, introducing the following indexer you may address an element of the vector as vector[i] or vector[0] or ...
        public T this[int index]
        {
            get
            {
                if (index >= Count || index < 0) throw new IndexOutOfRangeException();
                return data[index];
            }
            set
            {
                if (index >= Count || index < 0) throw new IndexOutOfRangeException();
                data[index] = value;
            }
        }

        // This private method allows extension of the existing capacity of the vector by another 'extraCapacity' elements.
        // The new capacity is equal to the existing one plus 'extraCapacity'.
        // It copies the elements of 'data' (the existing array) to 'newData' (the new array), and then makes data pointing to 'newData'.
        private void ExtendData(int extraCapacity)
        {
            T[] newData = new T[Capacity + extraCapacity];
            for (int i = 0; i < Count; i++) newData[i] = data[i];
            data = newData;
        }

        // This method adds a new element to the existing array.
        // If the internal array is out of capacity, its capacity is first extended to fit the new element.
        public void Add(T element)
        {
            if (Count == Capacity) ExtendData(DEFAULT_CAPACITY);
            data[Count] = element;
            Count++;
        }

        // This method searches for the specified object and returns the zero‐based index of the first occurrence within the entire data structure.
        // This method performs a linear search; therefore, this method is an O(n) runtime complexity operation.
        // If occurrence is not found, then the method returns –1.
        // Note that Equals is the proper method to compare two objects for equality, you must not use operator '=' for this purpose.
        public int IndexOf(T element)
        {
            for (var i = 0; i < Count; i++)
            {
                if (data[i].Equals(element)) return i;
            }
            return -1;
        }

        // TODO: Your task is to implement all the remaining methods.
        // Read the instruction carefully, study the code examples from above as they should help you to write the rest of the code.
        public void Insert(int index, T element)
        {
            // checking if the index is valid 
            if (index < 0 || index > Count)
            {
                throw new IndexOutOfRangeException("Index is out of range.");
            }
            // checking if the capacity needs to be increased 
            if (Count == Capacity)
            {
                ExtendData(DEFAULT_CAPACITY);
            }

            // shift elements to thr right if insrting any element in the middle , this ensures that no element overwrites the other if needed to be placed in the middle while still maintaining the order of the vector
            for (int i = Count - 1; i >= index; i--)
            { data[i + 1] = data[i]; }

            //inserting the new element at any specified index 
            data[index] = element;
            //increasing the count
            Count++;
        }

        public void Clear()
        {
            //setting the count to 0 
            Count = 0;
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = default; // Set to default value (e.g., 0 for int, null for reference types)
                data = new T[DEFAULT_CAPACITY];
            }
        }

        public bool Contains(T element)
        {
            //check all elements in the vector first 
            if (IndexOf(element) != -1)
                return true;
            else
            {
                return false;
            }

        }
        public bool Remove(T element)
        {

            int removeelement = IndexOf(element);
            if (removeelement != -1)
            {
                RemoveAt(removeelement);
                return true;
            }
            else
            {
                return false;
            }

        }

        public void RemoveAt(int index)
        {
            //checking if the index is in the valid range 
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException("index is outvof range.");

            }
            //shift elements one position to left to fill the gap 
            for (int i = index; i < Count - 1; i++)
            {
                data[i] = data[i + 1];

            }
            //setting the last element to default value so that it is no longer accessible and then decreasong the count 
            // data[Count - 1] = default(T);
            Count--;

        }

        public override string ToString()
        {
            //if the vector is empty , it should show empty square brackets []
            if (Count == 0)
            {
                return "[]";
            }
            //starting the string with stringbuilder object 
            StringBuilder result = new StringBuilder("[");
            for (int i = 0; i < Count; i++)
            { //append the current element to the result
                result.Append(data[i].ToString());
                // we will separate the elements with a comma if its not the last element 
                if (i < Count - 1)
                { result.Append(","); }
            }
            result.Append("]");
            return result.ToString();

        }



        public void Sort()
        {
            Array.Sort(data, 0, Count, Comparer<T>.Default);
        }

        public void Sort(IComparer<T> comparer)
        {
            Array.Sort(data, 0, Count, comparer ?? Comparer<T>.Default);
        }
       

public int BinarySearch(T item, IComparer<T> comparer)
{
    //  we will use default comparer if none is provided
    comparer ??= Comparer<T>.Default;

    int left = 0;            // Start of the search range
    int right = Count - 1;   // End of the search range

    // Continue searching while the range is valid
    while (left <= right)
    {
        int mid = (left + right) / 2; // Find the middle index

        int comparison = comparer.Compare(data[mid], item); // Compare item with middle element

        if (comparison == 0)
        {
            return mid; // Item found at index mid
        }
        else if (comparison < 0)
        {
            left = mid + 1; // Item is in the right half
        }
        else
        {
            right = mid - 1; // Item is in the left half
        }
    }

    return -1; // Item not found
}
       
        }

    }


