﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;

namespace FindTheCat
{
    public class FindTheCat
    {
       static int rows, columns; // dimensions for the rows and columns 
        static int[,] directions = new int[,] { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } }; // directions for moving in different directions

        public static int Solve(int[,] matrix)
        {
           rows = matrix.GetLength(0);
            columns = matrix.GetLength(1);
            // marking reachable cells from start to end 
            bool[,] reachableFromStart = BFS(matrix, 0, 0);
            bool[,] reachableFromEnd = BFS(matrix, rows - 1, columns - 1);

            int count = 0;
           // iterating to check each cell in the matrix 
            for (int r = 0; r < rows; r++)
              {
                for (int c = 0; c < columns; c++)
                {
                    if (matrix[r, c] != 1) continue; // Only checks walls

                    bool canConnectStart = false;
                    bool canConnectEnd = false;

                    for (int d = 0; d < 4; d++)
                    {
                        int nr = r + directions[d, 0];
                        int nc = c + directions[d, 1];

                        if (InsideTheBounds(nr, nc))
                        {
                            if (reachableFromStart[nr, nc]) canConnectStart = true;
                            if (reachableFromEnd[nr, nc]) canConnectEnd = true;
                        }
                    }
                            // if breaking this wall connects start and end zones count it 
                    if (canConnectStart && canConnectEnd)
                        count++;
                }
            }

            return count;
        }

        private static bool[,] BFS(int[,] matrix, int startR, int startC)
        {
            bool[,] visited = new bool[rows, columns];
            Queue<(int r, int c)> queue = new Queue<(int r, int c)>();
            queue.Enqueue((startR, startC));
            visited[startR, startC] = true;

            while (queue.Count > 0)
            {
                var (r, c) = queue.Dequeue();
                   // exploring the neighbouring cells 
                for (int d = 0; d < 4; d++)
                {
                    int nr = r + directions[d, 0];
                    int nc = c + directions[d, 1];

                    if (InsideTheBounds(nr, nc) && !visited[nr, nc] && matrix[nr, nc] == 0)
                    {
                        visited[nr, nc] = true;
                        queue.Enqueue((nr, nc));
                    }
                }
            }

            return visited;
        }

        private static bool InsideTheBounds(int r, int c)
        {
            return r >= 0 && r < rows && c >= 0 && c < columns;
        }
    }
        }

    

