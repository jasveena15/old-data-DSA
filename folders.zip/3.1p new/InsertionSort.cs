using System;
using System.Collections.Generic;
namespace Vector
{
    public class InsertionSort : ISorter
    {
        public void Sort<K>(K[] array, int index, int num, IComparer<K> comparer) where K : IComparable<K>
        {
            if (array == null) throw new ArgumentNullException(nameof(array)); // Ensure array is not null
            if (index < 0 || num < 0) throw new ArgumentOutOfRangeException(); // Validate index and num
            if (index + num > array.Length) throw new ArgumentException(); // Ensure range is within bounds

            // Perform Insertion Sort
            for (int i = index + 1; i < index + num; i++)
            {
                K key = array[i]; // Store the current element
                int j = i - 1;

                // Shift elements to the right to make space for the key
                while (j >= index && comparer.Compare(array[j], key) > 0)
                {
                    array[j + 1] = array[j];
                    j--;
                }

                array[j + 1] = key; // Place the key in the correct position
            }
        }
    }
}