using System;
using System.Collections.Generic;
namespace Vector
{
    public class BubbleSort : ISorter
    {
        public void Sort<K>(K[] array, int index, int num, IComparer<K> comparer) where K : IComparable<K>
        {
            if (array == null) throw new ArgumentNullException(nameof(array)); // Ensure array is not null
            if (index < 0 || num < 0) throw new ArgumentOutOfRangeException(); // Validate index and num
            if (index + num > array.Length) throw new ArgumentException(); // Ensure range is within bounds

            // Perform Bubble Sort
            for (int i = index; i < index + num - 1; i++)
            {
                for (int j = index; j < index + num - (i - index) - 1; j++)
                {
                    // Compare adjacent elements and swap if they are out of order
                    if (comparer.Compare(array[j], array[j + 1]) > 0)
                    {
                        (array[j], array[j + 1]) = (array[j + 1], array[j]); // Swap elements
                    }
                }
            }
        }
    }
}