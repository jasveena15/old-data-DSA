using System;
using System.Collections.Generic;

namespace Vector
{
    public class SelectionSort : ISorter
    {
        public void Sort<K>(K[] array, int index, int num, IComparer<K> comparer) where K : IComparable<K>
        {
            if (array == null) throw new ArgumentNullException(nameof(array)); // Ensure array is not null
            if (index < 0 || num < 0) throw new ArgumentOutOfRangeException(); // Validate index and num
            if (index + num > array.Length) throw new ArgumentException(); // Ensure range is within bounds

            // Perform Selection Sort
            for (int i = index; i < index + num - 1; i++)
            {
                int minIndex = i; // Assume the current element is the smallest

                // Find the smallest element in the remaining array
                for (int j = i + 1; j < index + num; j++)
                {
                    if (comparer.Compare(array[j], array[minIndex]) < 0)
                    {
                        minIndex = j; // Update the minimum index
                    }
                }

                // Swap the smallest element with the current element
                (array[i], array[minIndex]) = (array[minIndex], array[i]);
            }
        }
    }
}