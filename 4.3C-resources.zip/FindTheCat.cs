﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;

namespace FindTheCat
{
    public class FindTheCat
    {
       
        public static int Solve(int[,] matrix)
        {
            // You should replace this plug by your code.
            throw new NotImplementedException();
        }

    }
}